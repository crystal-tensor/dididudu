from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from .routers import auth, analysis, payments, reports

app = FastAPI(title="UP主竞争分析平台", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FRONTEND_DIR = "/Users/danielcrystal/work/dididudu/frontend"

# 静态资源改挂载到 /static，避免覆盖 /api/*
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

# 显式返回各页面
@app.get("/")
@app.get("/index.html")
def page_index():
    return FileResponse(f"{FRONTEND_DIR}/index.html")

@app.get("/pricing.html")
def page_pricing():
    return FileResponse(f"{FRONTEND_DIR}/pricing.html")

@app.get("/reports.html")
def page_reports():
    return FileResponse(f"{FRONTEND_DIR}/reports.html")

# API 路由
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(analysis.router, prefix="/api/analysis", tags=["analysis"])
app.include_router(payments.router, prefix="/api/payments", tags=["payments"])
app.include_router(reports.router, prefix="/api/reports", tags=["reports"])

@app.get("/api/health")
def health():
    return {"status": "ok"}
